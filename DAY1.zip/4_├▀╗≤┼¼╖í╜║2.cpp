#include <iostream>

class Camera
{
public:
	void take() { cout << "Camera take" << endl; }
};

class People
{
public:
	void useCamera(Camera* p) { p->take(); }
};

int main()
{
	People p;
	Camera c;
	p.useCamera(&c);
}

