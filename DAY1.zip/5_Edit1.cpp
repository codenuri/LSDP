#include <iostream>
#include <string>
#include <conio.h>

class Edit
{
	std::string data;
public:
	std::string getData()
	{
		std::cin >> data;
		return data;
	}
};
int main()
{
	Edit edit;
	while (1)
	{
		std::string s = edit.getData();
		std::cout << s << std::endl;
	}
}
