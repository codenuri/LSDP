#include <iostream>
#include <string>

class Person
{
	std::string name;
	int age;
public:
};

int main()
{
	Person p;
}