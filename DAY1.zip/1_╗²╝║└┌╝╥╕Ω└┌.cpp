#include <iostream>

class Base
{
public:
	Base()      { std::cout << "Base()" << std:endl; }
	Base(int a) { std::cout << "Base(int)" << std::endl; }
	~Base()     { std::cout << "~Base()" << std::endl; }
};
class Derived : public Base
{
public:
	Derived() 		{ std::cout << "Derived()" << endl; }
	Derived(int a)  { std::cout << "Derived(int)" << endl; }
	~Derived()		{ std::cout << "~Derived()" << endl; }
};

int main()
{
	Derived d1;
//	Derived d2(5);
}









